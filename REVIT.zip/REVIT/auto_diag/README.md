# AUTO DIAG (IN -> CLICK -> OUT)

Narzędzie do testów dynamiki, hamowania, zawieszenia i ściągania w samochodzie na bazie czujników smartfona (Dart + Flutter).

## Struktura projektu
- `lib/models/` — modele próbek (`SensorSample`) i zapisanych sesji (`TestSession`).
- `lib/services/` — obsługa czujników, GPS, barometru, audio oraz lokalny zapis i eksport.
- `lib/engine/` — filtrowanie szumów i analiza przejazdów (0-100, 80-120, hamowanie, wybieg, ściąganie).
- `lib/screens/` — ekran główny (START/STOP + kalibracja), podsumowanie oraz historia i porównania.
- `lib/widgets/` — kontrastowe wskaźniki na żywo.

## Kompilacja w chmurze
Każdy push na gałąź `main` lub ręczne uruchomienie w zakładce **Actions** (`.github/workflows/build.yml`) buduje plik `app-release.apk`.
