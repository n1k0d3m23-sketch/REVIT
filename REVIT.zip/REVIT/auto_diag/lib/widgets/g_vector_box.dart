import 'package:flutter/material.dart';

class GVectorBox extends StatelessWidget {
  final double axG; // Wzdłużne (+przyspieszenie, -hamowanie)
  final double ayG; // Boczne (+prawo, -lewo)

  const GVectorBox({
    super.key,
    required this.axG,
    required this.ayG,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        color: const Color(0xFF141417),
        border: Border.all(color: const Color(0xFF27272A)),
        borderRadius: BorderRadius.circular(6),
      ),
      child: CustomPaint(
        painter: _GVectorPainter(axG: axG, ayG: ayG),
        child: const Align(
          alignment: Alignment.topLeft,
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'G-VECTOR (MAX 1.5G)',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: Color(0xFFA1A1AA),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GVectorPainter extends CustomPainter {
  final double axG;
  final double ayG;

  _GVectorPainter({required this.axG, required this.ayG});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = (size.height / 2) - 14;

    final gridPaint = Paint()
      ..color = const Color(0xFF27272A)
      ..strokeWidth = 1;

    canvas.drawLine(Offset(center.dx - maxRadius, center.dy), Offset(center.dx + maxRadius, center.dy), gridPaint);
    canvas.drawLine(Offset(center.dx, center.dy - maxRadius), Offset(center.dx, center.dy + maxRadius), gridPaint);

    final circlePaint = Paint()
      ..color = const Color(0xFF3F3F46)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(center, maxRadius * 0.66, circlePaint);

    const scaleG = 1.5;
    final nx = (ayG / scaleG).clamp(-1.0, 1.0);
    final ny = (-axG / scaleG).clamp(-1.0, 1.0);

    final dotPos = Offset(
      center.dx + nx * maxRadius,
      center.dy + ny * maxRadius,
    );

    final dotPaint = Paint()..color = const Color(0xFFF97316);
    canvas.drawCircle(dotPos, 7, dotPaint);
  }

  @override
  bool shouldRepaint(covariant _GVectorPainter oldDelegate) =>
      oldDelegate.axG != axG || oldDelegate.ayG != ayG;
}
