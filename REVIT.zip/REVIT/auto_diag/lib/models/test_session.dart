import 'dart:convert';
import 'sensor_sample.dart';

enum TestMode {
  accel0to100('0-100 KM/H'),
  roll80to120('80-120 KM/H'),
  braking('HAMOWANIE G'),
  coastDown('WYBIEG / OPORY'),
  pullDrift('ŚCIĄGANIE / TOR'),
  suspension('ZAWIESZENIE / VIB');

  final String label;
  const TestMode(this.label);
}

class TestSession {
  final String id;
  final DateTime createdAt;
  final TestMode mode;
  final String label;
  final String note;
  final double? primaryMetric; // np. czas [s] lub szczytowe G
  final String primaryUnit;
  final double? secondaryMetric; // np. max G, dystans lub średni drift
  final String secondaryUnit;
  final List<SensorSample> samples;

  const TestSession({
    required this.id,
    required this.createdAt,
    required this.mode,
    required this.label,
    this.note = '',
    this.primaryMetric,
    this.primaryUnit = '',
    this.secondaryMetric,
    this.secondaryUnit = '',
    this.samples = const [],
  });

  TestSession copyWith({
    String? label,
    String? note,
    double? primaryMetric,
    String? primaryUnit,
    double? secondaryMetric,
    String? secondaryUnit,
    List<SensorSample>? samples,
  }) {
    return TestSession(
      id: id,
      createdAt: createdAt,
      mode: mode,
      label: label ?? this.label,
      note: note ?? this.note,
      primaryMetric: primaryMetric ?? this.primaryMetric,
      primaryUnit: primaryUnit ?? this.primaryUnit,
      secondaryMetric: secondaryMetric ?? this.secondaryMetric,
      secondaryUnit: secondaryUnit ?? this.secondaryUnit,
      samples: samples ?? this.samples,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'mode': mode.name,
        'label': label,
        'note': note,
        'primaryMetric': primaryMetric,
        'primaryUnit': primaryUnit,
        'secondaryMetric': secondaryMetric,
        'secondaryUnit': secondaryUnit,
        'samples': samples.map((s) => s.toJson()).toList(),
      };

  factory TestSession.fromJson(Map<String, dynamic> json) {
    final modeName = json['mode'] as String?;
    final parsedMode = TestMode.values.firstWhere(
      (m) => m.name == modeName,
      orElse: () => TestMode.accel0to100,
    );
    final rawSamples = (json['samples'] as List<dynamic>?) ?? const [];
    return TestSession(
      id: json['id'] as String? ?? DateTime.now().millisecondsSinceEpoch.toString(),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      mode: parsedMode,
      label: json['label'] as String? ?? 'TEST',
      note: json['note'] as String? ?? '',
      primaryMetric: (json['primaryMetric'] as num?)?.toDouble(),
      primaryUnit: json['primaryUnit'] as String? ?? '',
      secondaryMetric: (json['secondaryMetric'] as num?)?.toDouble(),
      secondaryUnit: json['secondaryUnit'] as String? ?? '',
      samples: rawSamples
          .map((e) => SensorSample.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  String toJsonString() => jsonEncode(toJson());

  String toCsvString() {
    final buffer = StringBuffer();
    buffer.writeln('timestamp_ms,ax_g,ay_g,az_g,gyro_x,gyro_y,gyro_z,speed_kmh,altitude_m,pressure_hpa,audio_db');
    for (final s in samples) {
      buffer.writeln(s.toCsvRow());
    }
    return buffer.toString();
  }
}
