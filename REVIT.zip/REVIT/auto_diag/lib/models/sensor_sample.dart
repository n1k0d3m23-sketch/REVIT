class SensorSample {
  final int timestampMs;
  final double axG; // Przyspieszenie wzdłużne (G) po kalibracji
  final double ayG; // Przyspieszenie boczne (G) po kalibracji
  final double azG; // Przyspieszenie pionowe (G) po kalibracji
  final double gyroX; // Prędkość kątowa X (rad/s)
  final double gyroY; // Prędkość kątowa Y (rad/s)
  final double gyroZ; // Prędkość kątowa Z (rad/s)
  final double speedKmh; // Prędkość z GPS (km/h)
  final double altitudeM; // Wysokość n.p.m. (m)
  final double pressureHpa; // Ciśnienie z barometru (hPa)
  final double? audioDb; // Opcjonalny poziom głośności (dB)

  const SensorSample({
    required this.timestampMs,
    required this.axG,
    required this.ayG,
    required this.azG,
    required this.gyroX,
    required this.gyroY,
    required this.gyroZ,
    required this.speedKmh,
    required this.altitudeM,
    required this.pressureHpa,
    this.audioDb,
  });

  Map<String, dynamic> toJson() => {
        't': timestampMs,
        'ax': axG,
        'ay': ayG,
        'az': azG,
        'gx': gyroX,
        'gy': gyroY,
        'gz': gyroZ,
        'v': speedKmh,
        'alt': altitudeM,
        'hpa': pressureHpa,
        'db': audioDb,
      };

  factory SensorSample.fromJson(Map<String, dynamic> json) => SensorSample(
        timestampMs: (json['t'] as num?)?.toInt() ?? 0,
        axG: (json['ax'] as num?)?.toDouble() ?? 0.0,
        ayG: (json['ay'] as num?)?.toDouble() ?? 0.0,
        azG: (json['az'] as num?)?.toDouble() ?? 0.0,
        gyroX: (json['gx'] as num?)?.toDouble() ?? 0.0,
        gyroY: (json['gy'] as num?)?.toDouble() ?? 0.0,
        gyroZ: (json['gz'] as num?)?.toDouble() ?? 0.0,
        speedKmh: (json['v'] as num?)?.toDouble() ?? 0.0,
        altitudeM: (json['alt'] as num?)?.toDouble() ?? 0.0,
        pressureHpa: (json['hpa'] as num?)?.toDouble() ?? 1013.25,
        audioDb: (json['db'] as num?)?.toDouble(),
      );

  String toCsvRow() =>
      '$timestampMs,${axG.toStringAsFixed(4)},${ayG.toStringAsFixed(4)},${azG.toStringAsFixed(4)},'
      '${gyroX.toStringAsFixed(4)},${gyroY.toStringAsFixed(4)},${gyroZ.toStringAsFixed(4)},'
      '${speedKmh.toStringAsFixed(2)},${altitudeM.toStringAsFixed(2)},${pressureHpa.toStringAsFixed(2)},'
      '${audioDb?.toStringAsFixed(1) ?? ''}';
}
