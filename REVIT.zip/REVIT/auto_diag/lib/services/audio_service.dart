import 'dart:async';
import 'package:record/record.dart';

class AudioService {
  final AudioRecorder _recorder = AudioRecorder();
  bool _isListening = false;
  double _lastDb = -80.0;
  Timer? _pollTimer;

  double get lastDb => _lastDb;
  bool get isListening => _isListening;

  Future<bool> start() async {
    if (_isListening) return true;
    final hasPerm = await _recorder.hasPermission();
    if (!hasPerm) return false;

    await _recorder.start(
      const RecordConfig(encoder: AudioEncoder.pcm16bits, sampleRate: 16000, numChannels: 1),
      path: '',
    ).catchError((_) {});

    _isListening = true;
    _pollTimer = Timer.periodic(const Duration(milliseconds: 100), (_) async {
      if (!_isListening) return;
      try {
        final amp = await _recorder.getAmplitude();
        _lastDb = amp.current;
      } catch (_) {}
    });
    return true;
  }

  Future<void> stop() async {
    _pollTimer?.cancel();
    _pollTimer = null;
    _isListening = false;
    try {
      await _recorder.stop();
    } catch (_) {}
  }

  void dispose() {
    _pollTimer?.cancel();
    _recorder.dispose();
  }
}
