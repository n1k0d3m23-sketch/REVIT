import 'dart:async';
import 'package:environment_sensors/environment_sensors.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../engine/signal_filter.dart';
import '../models/sensor_sample.dart';
import 'audio_service.dart';

class SensorsService {
  final EnvironmentSensors _envSensors = EnvironmentSensors();
  final AudioService audioService = AudioService();

  final SignalFilter _axFilter = SignalFilter(alpha: 0.25);
  final SignalFilter _ayFilter = SignalFilter(alpha: 0.25);
  final SignalFilter _azFilter = SignalFilter(alpha: 0.25);

  double _offsetAx = 0.0;
  double _offsetAy = 0.0;
  double _offsetAz = 0.0;

  double _rawAxG = 0.0;
  double _rawAyG = 0.0;
  double _rawAzG = 0.0;
  double _gyroX = 0.0;
  double _gyroY = 0.0;
  double _gyroZ = 0.0;
  double _speedKmh = 0.0;
  double _altitudeM = 0.0;
  double _pressureHpa = 1013.25;
  bool _barometerAvailable = false;

  StreamSubscription? _accelSub;
  StreamSubscription? _gyroSub;
  StreamSubscription<Position>? _gpsSub;
  StreamSubscription<double>? _baroSub;
  Timer? _tickTimer;

  final _sampleController = StreamController<SensorSample>.broadcast();
  Stream<SensorSample> get sampleStream => _sampleController.stream;

  bool get barometerAvailable => _barometerAvailable;
  double get currentSpeedKmh => _speedKmh;
  double get currentPressureHpa => _pressureHpa;
  double get currentAltitudeM => _altitudeM;

  static const double _gravity = 9.80665;

  Future<void> initSensors({bool enableAudio = false}) async {
    _barometerAvailable = await _envSensors.getSensorAvailable(SensorType.Pressure);

    _accelSub?.cancel();
    _accelSub = userAccelerometerEventStream(
      samplingPeriod: const Duration(milliseconds: 20),
    ).listen((UserAccelerometerEvent event) {
      _rawAxG = event.x / _gravity;
      _rawAyG = event.y / _gravity;
      _rawAzG = event.z / _gravity;
    });

    _gyroSub?.cancel();
    _gyroSub = gyroscopeEventStream(
      samplingPeriod: const Duration(milliseconds: 20),
    ).listen((GyroscopeEvent event) {
      _gyroX = event.x;
      _gyroY = event.y;
      _gyroZ = event.z;
    });

    if (_barometerAvailable) {
      _baroSub?.cancel();
      _baroSub = _envSensors.pressure.listen((double hpa) {
        _pressureHpa = hpa;
      });
    }

    await _initLocation();

    if (enableAudio) {
      await audioService.start();
    }

    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      final calAx = _axFilter.update(_rawAxG - _offsetAx);
      final calAy = _ayFilter.update(_rawAyG - _offsetAy);
      final calAz = _azFilter.update(_rawAzG - _offsetAz);

      _sampleController.add(
        SensorSample(
          timestampMs: DateTime.now().millisecondsSinceEpoch,
          axG: calAx,
          ayG: calAy,
          azG: calAz,
          gyroX: _gyroX,
          gyroY: _gyroY,
          gyroZ: _gyroZ,
          speedKmh: _speedKmh,
          altitudeM: _altitudeM,
          pressureHpa: _pressureHpa,
          audioDb: audioService.isListening ? audioService.lastDb : null,
        ),
      );
    });
  }

  Future<void> _initLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return;
    }

    _gpsSub?.cancel();
    _gpsSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 0,
      ),
    ).listen((Position pos) {
      _speedKmh = (pos.speed * 3.6).clamp(0.0, 400.0);
      _altitudeM = pos.altitude;
    });
  }

  void calibrateZero() {
    _offsetAx = _rawAxG;
    _offsetAy = _rawAyG;
    _offsetAz = _rawAzG;
    _axFilter.reset(0.0);
    _ayFilter.reset(0.0);
    _azFilter.reset(0.0);
  }

  Future<void> dispose() async {
    _tickTimer?.cancel();
    await _accelSub?.cancel();
    await _gyroSub?.cancel();
    await _gpsSub?.cancel();
    await _baroSub?.cancel();
    await audioService.stop();
    audioService.dispose();
    await _sampleController.close();
  }
}
