import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/test_session.dart';

class StorageService {
  static const String _sessionsKey = 'auto_diag_sessions_v1';

  Future<List<TestSession>> loadSessions() async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_sessionsKey) ?? const [];
    final sessions = <TestSession>[];
    for (final raw in rawList) {
      try {
        final decoded = jsonDecode(raw) as Map<String, dynamic>;
        sessions.add(TestSession.fromJson(decoded));
      } catch (_) {}
    }
    sessions.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return sessions;
  }

  Future<void> saveSession(TestSession session) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await loadSessions();
    current.removeWhere((s) => s.id == session.id);
    current.insert(0, session);

    final encoded = current.map((s) => s.toJsonString()).toList();
    await prefs.setStringList(_sessionsKey, encoded);
  }

  Future<void> deleteSession(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await loadSessions();
    current.removeWhere((s) => s.id == id);
    await prefs.setStringList(
      _sessionsKey,
      current.map((s) => s.toJsonString()).toList(),
    );
  }

  Future<File> exportSessionCsv(TestSession session) async {
    final dir = await getApplicationDocumentsDirectory();
    final safeName = session.label.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
    final file = File('${dir.path}/auto_diag_${safeName}_${session.id}.csv');
    await file.writeAsString(session.toCsvString());
    return file;
  }
}
