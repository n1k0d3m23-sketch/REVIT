import 'dart:math';

class SignalFilter {
  final double alpha; // Współczynnik wygładzania EMA (0..1; niższy = mocniejsze wygładzenie)
  double? _filteredValue;

  SignalFilter({this.alpha = 0.25});

  double update(double rawValue) {
    if (_filteredValue == null) {
      _filteredValue = rawValue;
      return rawValue;
    }
    _filteredValue = alpha * rawValue + (1.0 - alpha) * _filteredValue!;
    return _filteredValue!;
  }

  void reset([double? initialValue]) {
    _filteredValue = initialValue;
  }

  double get value => _filteredValue ?? 0.0;

  static double rms(List<double> values) {
    if (values.isEmpty) return 0.0;
    double sumSq = 0.0;
    for (final v in values) {
      sumSq += v * v;
    }
    return sqrt(sumSq / values.length);
  }
}
