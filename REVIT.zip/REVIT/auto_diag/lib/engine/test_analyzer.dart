import 'dart:math';
import '../models/sensor_sample.dart';
import '../models/test_session.dart';
import 'signal_filter.dart';

class AnalysisResult {
  final double? primaryMetric;
  final String primaryUnit;
  final double? secondaryMetric;
  final String secondaryUnit;
  final String summaryLine;

  const AnalysisResult({
    this.primaryMetric,
    this.primaryUnit = '',
    this.secondaryMetric,
    this.secondaryUnit = '',
    this.summaryLine = '',
  });
}

class TestAnalyzer {
  static AnalysisResult analyze(TestMode mode, List<SensorSample> samples) {
    if (samples.isEmpty) {
      return const AnalysisResult(summaryLine: 'Brak próbek z czujników.');
    }

    switch (mode) {
      case TestMode.accel0to100:
        return _analyzeSpeedWindow(samples, startKmh: 5.0, targetKmh: 100.0, label: '0-100');
      case TestMode.roll80to120:
        return _analyzeSpeedWindow(samples, startKmh: 80.0, targetKmh: 120.0, label: '80-120');
      case TestMode.braking:
        return _analyzeBraking(samples);
      case TestMode.coastDown:
        return _analyzeCoastDown(samples);
      case TestMode.pullDrift:
        return _analyzePullDrift(samples);
      case TestMode.suspension:
        return _analyzeSuspension(samples);
    }
  }

  static AnalysisResult _analyzeSpeedWindow(
    List<SensorSample> samples, {
    required double startKmh,
    required double targetKmh,
    required String label,
  }) {
    SensorSample? startSample;
    SensorSample? endSample;
    double maxAxG = 0.0;

    for (final s in samples) {
      if (s.axG > maxAxG) maxAxG = s.axG;
      if (startSample == null && s.speedKmh >= startKmh) {
        startSample = s;
      } else if (startSample != null && endSample == null && s.speedKmh >= targetKmh) {
        endSample = s;
        break;
      }
    }

    if (startSample != null && endSample != null && endSample.timestampMs > startSample.timestampMs) {
      final elapsedSec = (endSample.timestampMs - startSample.timestampMs) / 1000.0;
      return AnalysisResult(
        primaryMetric: elapsedSec,
        primaryUnit: 's',
        secondaryMetric: maxAxG,
        secondaryUnit: 'G max',
        summaryLine: '$label: ${elapsedSec.toStringAsFixed(2)} s | Szczyt: ${maxAxG.toStringAsFixed(2)} G',
      );
    }

    final maxSpeed = samples.map((e) => e.speedKmh).reduce(max);
    return AnalysisResult(
      primaryMetric: maxSpeed,
      primaryUnit: 'km/h max',
      secondaryMetric: maxAxG,
      secondaryUnit: 'G max',
      summaryLine: 'Nie osiągnięto $targetKmh km/h. Max prędkość: ${maxSpeed.toStringAsFixed(1)} km/h',
    );
  }

  static AnalysisResult _analyzeBraking(List<SensorSample> samples) {
    double peakDecelG = 0.0;
    for (final s in samples) {
      final decel = -s.axG;
      if (decel > peakDecelG) peakDecelG = decel;
    }
    final peakMs2 = peakDecelG * 9.80665;
    return AnalysisResult(
      primaryMetric: peakDecelG,
      primaryUnit: 'G',
      secondaryMetric: peakMs2,
      secondaryUnit: 'm/s²',
      summaryLine: 'Szczyt hamowania: ${peakDecelG.toStringAsFixed(2)} G (${peakMs2.toStringAsFixed(1)} m/s²)',
    );
  }

  static AnalysisResult _analyzeCoastDown(List<SensorSample> samples) {
    if (samples.length < 2) {
      return const AnalysisResult(summaryLine: 'Za mało danych do wybiegu.');
    }
    final first = samples.first;
    final last = samples.last;
    final dtSec = max(0.1, (last.timestampMs - first.timestampMs) / 1000.0);
    final dvKmh = first.speedKmh - last.speedKmh;
    final decelKmhPerSec = dvKmh / dtSec;
    final dPress = last.pressureHpa - first.pressureHpa;

    return AnalysisResult(
      primaryMetric: decelKmhPerSec,
      primaryUnit: 'km/h/s',
      secondaryMetric: dPress,
      secondaryUnit: 'hPa',
      summaryLine: 'Spadek prędkości: ${decelKmhPerSec.toStringAsFixed(2)} km/h/s | ΔP: ${dPress.toStringAsFixed(2)} hPa',
    );
  }

  static AnalysisResult _analyzePullDrift(List<SensorSample> samples) {
    final avgAy = samples.map((e) => e.ayG).reduce((a, b) => a + b) / samples.length;
    final avgGz = samples.map((e) => e.gyroZ).reduce((a, b) => a + b) / samples.length;
    return AnalysisResult(
      primaryMetric: avgAy,
      primaryUnit: 'G bok',
      secondaryMetric: avgGz,
      secondaryUnit: 'rad/s',
      summaryLine: 'Śr. boczne: ${avgAy >= 0 ? "+" : ""}${avgAy.toStringAsFixed(3)} G | Yaw: ${avgGz.toStringAsFixed(3)} rad/s',
    );
  }

  static AnalysisResult _analyzeSuspension(List<SensorSample> samples) {
    final zValues = samples.map((e) => e.azG).toList();
    final vibRmsG = SignalFilter.rms(zValues);
    double maxRollGyro = 0.0;
    for (final s in samples) {
      final absGyro = s.gyroX.abs();
      if (absGyro > maxRollGyro) maxRollGyro = absGyro;
    }
    return AnalysisResult(
      primaryMetric: vibRmsG,
      primaryUnit: 'G RMS',
      secondaryMetric: maxRollGyro,
      secondaryUnit: 'rad/s',
      summaryLine: 'Wibracje pionowe RMS: ${vibRmsG.toStringAsFixed(3)} G | Przechył max: ${maxRollGyro.toStringAsFixed(2)} rad/s',
    );
  }
}
