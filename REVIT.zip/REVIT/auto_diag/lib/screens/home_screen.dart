import 'dart:async';
import 'package:flutter/material.dart';
import '../engine/test_analyzer.dart';
import '../models/sensor_sample.dart';
import '../models/test_session.dart';
import '../services/sensors_service.dart';
import '../services/storage_service.dart';
import '../widgets/g_vector_box.dart';
import '../widgets/telemetry_readout.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SensorsService _sensors = SensorsService();
  final StorageService _storage = StorageService();
  final TextEditingController _labelController = TextEditingController(text: 'TEST 1');

  TestMode _selectedMode = TestMode.accel0to100;
  bool _isRecording = false;
  bool _audioEnabled = false;
  final List<SensorSample> _recordedSamples = [];

  SensorSample? _latestSample;
  StreamSubscription<SensorSample>? _sub;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await _sensors.initSensors(enableAudio: _audioEnabled);
    _sub = _sensors.sampleStream.listen((sample) {
      if (!mounted) return;
      if (_isRecording) {
        _recordedSamples.add(sample);
      }
      setState(() {
        _latestSample = sample;
      });
    });
  }

  Future<void> _toggleAudio() async {
    setState(() => _audioEnabled = !_audioEnabled);
    if (_audioEnabled) {
      await _sensors.audioService.start();
    } else {
      await _sensors.audioService.stop();
    }
  }

  void _calibrate() {
    _sensors.calibrateZero();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('SKALIBROWANO NA ZERO'),
        duration: Duration(milliseconds: 900),
      ),
    );
  }

  Future<void> _toggleRecord() async {
    if (!_isRecording) {
      setState(() {
        _recordedSamples.clear();
        _isRecording = true;
      });
    } else {
      setState(() => _isRecording = false);
      final samplesCopy = List<SensorSample>.from(_recordedSamples);
      final analysis = TestAnalyzer.analyze(_selectedMode, samplesCopy);

      final session = TestSession(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        createdAt: DateTime.now(),
        mode: _selectedMode,
        label: _labelController.text.trim().isEmpty
            ? _selectedMode.label
            : _labelController.text.trim(),
        primaryMetric: analysis.primaryMetric,
        primaryUnit: analysis.primaryUnit,
        secondaryMetric: analysis.secondaryMetric,
        secondaryUnit: analysis.secondaryUnit,
        samples: samplesCopy,
      );

      await _storage.saveSession(session);
      if (!mounted) return;
      Navigator.pushNamed(context, '/summary', arguments: session);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _labelController.dispose();
    _sensors.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = _latestSample;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF09090B),
        title: const Text(
          'AUTO DIAG',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5),
        ),
        actions: [
          IconButton(
            onPressed: _toggleAudio,
            icon: Icon(_audioEnabled ? Icons.mic : Icons.mic_off),
            tooltip: 'Mikrofon dB',
          ),
          TextButton(
            onPressed: () => Navigator.pushNamed(context, '/history'),
            child: const Text(
              'HISTORIA',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFF97316)),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: TestMode.values.map((mode) {
                  final active = mode == _selectedMode;
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(
                      label: Text(
                        mode.label,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: active ? Colors.black : Colors.white,
                        ),
                      ),
                      selected: active,
                      selectedColor: const Color(0xFFF97316),
                      backgroundColor: const Color(0xFF141417),
                      onSelected: _isRecording
                          ? null
                          : (_) => setState(() => _selectedMode = mode),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _labelController,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                isDense: true,
                labelText: 'ETYKIETA PRZEJAZDU (NP. PRZED SWORZNIEM)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TelemetryReadout(
                    label: 'PRĘDKOŚĆ GPS',
                    value: s != null ? s.speedKmh.toStringAsFixed(0) : '--',
                    unit: 'km/h',
                    accentColor: const Color(0xFF22C55E),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TelemetryReadout(
                    label: 'WZDŁUŻNE (AX)',
                    value: s != null ? s.axG.toStringAsFixed(2) : '--',
                    unit: 'G',
                    accentColor: const Color(0xFFF97316),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TelemetryReadout(
                    label: 'BOCZNE (AY)',
                    value: s != null ? s.ayG.toStringAsFixed(2) : '--',
                    unit: 'G',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TelemetryReadout(
                    label: _sensors.barometerAvailable ? 'BAROMETR' : 'WYSOKOŚĆ GPS',
                    value: s != null
                        ? (_sensors.barometerAvailable
                            ? s.pressureHpa.toStringAsFixed(1)
                            : s.altitudeM.toStringAsFixed(0))
                        : '--',
                    unit: _sensors.barometerAvailable ? 'hPa' : 'm',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            GVectorBox(
              axG: s?.axG ?? 0.0,
              ayG: s?.ayG ?? 0.0,
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'PRÓBKI: ${_recordedSamples.length}',
                  style: const TextStyle(fontSize: 12, color: Color(0xFFA1A1AA)),
                ),
                if (_audioEnabled && s?.audioDb != null)
                  Text(
                    'AUDIO: ${s!.audioDb!.toStringAsFixed(1)} dB',
                    style: const TextStyle(fontSize: 12, color: Color(0xFFA1A1AA)),
                  ),
              ],
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: OutlinedButton(
                    onPressed: _isRecording ? null : _calibrate,
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      side: const BorderSide(color: Color(0xFF52525B)),
                    ),
                    child: const Text(
                      'ZERO / KALIBRUJ',
                      style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 3,
                  child: ElevatedButton(
                    onPressed: _toggleRecord,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isRecording
                          ? const Color(0xFFEF4444)
                          : const Color(0xFF22C55E),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: Text(
                      _isRecording ? 'STOP / ZAPISZ' : 'START TESTU',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
