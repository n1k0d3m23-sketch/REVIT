import 'package:flutter/material.dart';
import '../engine/test_analyzer.dart';
import '../models/test_session.dart';
import '../services/storage_service.dart';

class SummaryScreen extends StatelessWidget {
  final TestSession session;

  const SummaryScreen({super.key, required this.session});

  @override
  Widget build(BuildContext context) {
    final analysis = TestAnalyzer.analyze(session.mode, session.samples);
    final storage = StorageService();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF09090B),
        title: Text(session.label.toUpperCase()),
      ),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              session.mode.label,
              style: const TextStyle(color: Color(0xFFF97316), fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF141417),
                border: Border.all(color: const Color(0xFF27272A)),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    analysis.primaryMetric != null
                        ? '${analysis.primaryMetric!.toStringAsFixed(2)} ${analysis.primaryUnit}'
                        : 'BRAK WYNIKU',
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF22C55E),
                    ),
                  ),
                  if (analysis.secondaryMetric != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      'Dodatkowo: ${analysis.secondaryMetric!.toStringAsFixed(2)} ${analysis.secondaryUnit}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ],
                  const SizedBox(height: 10),
                  Text(
                    analysis.summaryLine,
                    style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 13),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Zapisanych próbek: ${session.samples.length}',
                    style: const TextStyle(color: Color(0xFF71717A), fontSize: 12),
                  ),
                ],
              ),
            ),
            const Spacer(),
            OutlinedButton.icon(
              onPressed: () async {
                final file = await storage.exportSessionCsv(session);
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Zapisano CSV: ${file.path}')),
                );
              },
              icon: const Icon(Icons.download),
              label: const Text('EKSPORTUJ CSV'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/')),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF97316),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text(
                'KOLEJNY TEST',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
