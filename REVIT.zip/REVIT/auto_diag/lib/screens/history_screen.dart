import 'package:flutter/material.dart';
import '../models/test_session.dart';
import '../services/storage_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final StorageService _storage = StorageService();
  List<TestSession> _sessions = [];
  TestSession? _selectedA;
  TestSession? _selectedB;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await _storage.loadSessions();
    if (!mounted) return;
    setState(() {
      _sessions = list;
      _loading = false;
    });
  }

  String _formatDiff() {
    if (_selectedA == null ||
        _selectedB == null ||
        _selectedA!.primaryMetric == null ||
        _selectedB!.primaryMetric == null) {
      return 'Wybierz 2 testy (A i B), aby porównać różnicę.';
    }
    final diff = _selectedB!.primaryMetric! - _selectedA!.primaryMetric!;
    final sign = diff > 0 ? '+' : '';
    return '${_selectedB!.label} vs ${_selectedA!.label}: '
        '$sign${diff.toStringAsFixed(2)} ${_selectedA!.primaryUnit}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF09090B),
        title: const Text('HISTORIA I PORÓWNANIA'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.all(12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF141417),
                    border: Border.all(color: const Color(0xFFF97316)),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    _formatDiff(),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
                Expanded(
                  child: _sessions.isEmpty
                      ? const Center(child: Text('Brak zapisanych testów.'))
                      : ListView.builder(
                          itemCount: _sessions.length,
                          itemBuilder: (context, index) {
                            final item = _sessions[index];
                            final isA = _selectedA?.id == item.id;
                            final isB = _selectedB?.id == item.id;
                            return ListTile(
                              tileColor: const Color(0xFF141417),
                              title: Text(
                                '${item.label} [${item.mode.label}]',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                item.primaryMetric != null
                                    ? '${item.primaryMetric!.toStringAsFixed(2)} ${item.primaryUnit}'
                                    : 'Brak wyniku',
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ChoiceChip(
                                    label: const Text('A'),
                                    selected: isA,
                                    onSelected: (_) => setState(() => _selectedA = item),
                                  ),
                                  const SizedBox(width: 4),
                                  ChoiceChip(
                                    label: const Text('B'),
                                    selected: isB,
                                    onSelected: (_) => setState(() => _selectedB = item),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline),
                                    onPressed: () async {
                                      await _storage.deleteSession(item.id);
                                      await _load();
                                    },
                                  ),
                                ],
                              ),
                              onTap: () => Navigator.pushNamed(
                                context,
                                '/summary',
                                arguments: item,
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
